package assignment1.au615049;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;

import java.io.Serializable;
import java.lang.reflect.Field;

public class Country implements Serializable {
    public String name, note, countryCode;
    public int cases, deaths;
    public double rating = -1;

    public Country(String name, int cases, int deaths, double rating, String countryCode)
    {
        this.name = name;
        this.cases = cases;
        this.deaths = deaths;
        this.rating = rating;
        this.countryCode = countryCode;
    }

    public Country(String name, int cases, int deaths, String countryCode)
    {
        this.name = name;
        this.cases = cases;
        this.deaths = deaths;
        this.rating = -1;
        this.countryCode = countryCode;
    }

    public String getRating(final Context context) {
        if(rating != -1) {
            return String.valueOf(rating);
        } else{
            return context.getResources().getString(R.string.txtUserRatingDefault);
        }
    }

    public String getNote(final Context context) {
        if(note != null) {
            return note;
        } else{
            return context.getResources().getString(R.string.txtDefaultUserNote);
        }
    }

    public int getFlagResourceId() {
        return getResId(countryCode, R.drawable.class);
    }

    public static int getResId(String resName, Class<?> c) {

        // Teacher help, taken from: https://stackoverflow.com/questions/4427608/android-getting-resource-id-from-string

        try {
            Field idField = c.getDeclaredField(resName);
            return idField.getInt(idField);
        } catch (Exception e) {
            e.printStackTrace();
            return -1;
        }
    }
}
