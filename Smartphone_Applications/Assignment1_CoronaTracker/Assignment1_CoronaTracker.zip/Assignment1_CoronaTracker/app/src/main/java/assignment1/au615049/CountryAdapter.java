package assignment1.au615049;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CountryAdapter extends RecyclerView.Adapter<CountryAdapter.CountryViewHolder>
{

    Context context;

    public interface ICountryItemClickedListener {
        void onCountryClicked(int index);
    }

    private ICountryItemClickedListener listener;

    private ArrayList<Country> countryList;

    public CountryAdapter(ICountryItemClickedListener listener, Context context)
    {
        this.listener = listener;
        this.context = context;
    }

    public void updateCountryList(ArrayList<Country> lists){
        countryList = lists;
        notifyDataSetChanged();
    }

    // The onCreate function used by the Recycler View.
    @NonNull
    @Override
    public CountryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View v;
        v = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_country_item, parent, false);
        CountryViewHolder vh = new CountryViewHolder(v, listener);
        return vh;
    }

    // Used by the Recycler View Adapter to update each element as it's shown.
    @Override
    public void onBindViewHolder(@NonNull CountryViewHolder holder, int position) {
        Country c = countryList.get(position);

        holder.txtCountryName.setText(c.name);
        holder.txtCasesDeaths.setText(c.cases + " / " + c.deaths);
        holder.txtRating.setText(String.valueOf(c.getRating(context)));
        holder.imgFlag.setImageResource(c.getFlagResourceId());
    }

    // Used by the Recycler View Adapter.
    @Override
    public int getItemCount() {
        return countryList.size();
    }

    // View holder class. Holds the information of a single item in the recycler view.
    public class CountryViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imgFlag;
        TextView txtCountryName, txtRating, txtCasesDeaths;

        ICountryItemClickedListener listener;

        // View holder constructor. Binds to the elements in the layout.
        public CountryViewHolder(@NonNull View itemView, ICountryItemClickedListener countryItemClickedListener) {
            super(itemView);


            imgFlag = itemView.findViewById(R.id.imgFlag);
            txtCountryName = itemView.findViewById(R.id.txtCountryName);
            txtCasesDeaths = itemView.findViewById(R.id.txtCasesDeaths);
            txtRating = itemView.findViewById(R.id.txtRating);
            listener = countryItemClickedListener;

            itemView.setOnClickListener(this);
        }

        // The listener interface function that returns the clicked index in the recyclerview.
        @Override
        public void onClick(View view)
        {
            listener.onCountryClicked(getAdapterPosition());
        }
    }
}
