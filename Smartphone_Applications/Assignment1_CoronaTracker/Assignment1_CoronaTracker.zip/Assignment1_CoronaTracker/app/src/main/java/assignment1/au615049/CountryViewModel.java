package assignment1.au615049;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.ArrayList;

public class CountryViewModel extends ViewModel {
    MutableLiveData<ArrayList<Country>> countries;

    public LiveData<ArrayList<Country>> getCountriesLiveData () {
        if (countries == null) {
            countries = new MutableLiveData<>();
            ArrayList<Country> countryList = createData();
            countries.setValue(countryList);
        }
        return countries;
    }

    public ArrayList<Country> getCountryList(){
        return getCountriesLiveData().getValue();
    }

    public void editCountry(int index, Country country){
        getCountryList().set(index, country);
    }

    public ArrayList<Country> createData(){
        ArrayList<Country> countryList = new ArrayList<>();

        countryList.add(new Country("Denmark", 21836, 635, "dk"));
        countryList.add(new Country("Germany", 269048, 9376, "de"));
        countryList.add(new Country("Finland", 8799, 339, "fi"));
        countryList.add(new Country("Russia", 1081152, 18996, "ru"));
        countryList.add(new Country("China", 90294, 4736,  "cn"));
        countryList.add(new Country("Canada", 142866, 9248, "ca"));
        countryList.add(new Country("Japan", 77488, 1490, "jp"));
        countryList.add(new Country("Norway", 12644, 266, "no"));
        countryList.add(new Country("Sweden", 87885, 5864, "se"));
        countryList.add(new Country("USA", 6674411, 197633, "us"));

        return countryList;
    }
}
