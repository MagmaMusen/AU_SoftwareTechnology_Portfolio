package assignment1.au615049;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class EditActivity extends AppCompatActivity {



    Button btnCancel, btnSave;
    EditText noteInput;
    Country country;
    SeekBar ratingInput;
    TextView txtName, txtRating;
    ImageView imgFlag;
    int index;
    double tempRating;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        getSupportActionBar().setTitle("Edit Country Notes and Rating");

        Intent data = getIntent();
        country = (Country)data.getSerializableExtra(Constants.COUNTRYCLASS);

        findActivityViews();
        setActivityViews();

        tempRating = country.rating;

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                country.rating = tempRating;
                country.note = noteInput.getText().toString();
                gotoDetailActivitySave();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoDetailActivityCancel();
            }
        });

        ratingInput.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                tempRating = ((double)progress)/10;
                UpdateRating();
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    private void findActivityViews(){
        imgFlag = findViewById(R.id.imgFlagEdit);
        btnCancel = findViewById(R.id.btnEditCancel);
        btnSave = findViewById(R.id.btnSave);
        noteInput = findViewById(R.id.etxtEditNote);
        ratingInput = findViewById(R.id.skbRating);
        txtName = findViewById(R.id.txtCountryName);
        txtRating = findViewById(R.id.txtEditUserRating);
    }

    private void setActivityViews(){
        imgFlag.setImageResource(country.getFlagResourceId());
        txtRating.setText(country.getRating(this));
        txtName.setText(country.name);
        ratingInput.setMax(100);
        if(country.rating != -1) {
            ratingInput.setProgress((int)(country.rating*10));
        }
        noteInput.setText(country.getNote(this));
    }

    private void UpdateRating() {
        txtRating.setText(String.valueOf(tempRating));
    }

    private void gotoDetailActivitySave() {
        Intent intent = new Intent();
        intent.putExtra(Constants.COUNTRYCLASS, country);
        setResult(RESULT_OK, intent);
        finish();
    }

    private void gotoDetailActivityCancel() {
        Intent intent = new Intent();
        intent.putExtra(Constants.COUNTRYCLASS, country);
        setResult(RESULT_CANCELED, intent);
        finish();
    }
}