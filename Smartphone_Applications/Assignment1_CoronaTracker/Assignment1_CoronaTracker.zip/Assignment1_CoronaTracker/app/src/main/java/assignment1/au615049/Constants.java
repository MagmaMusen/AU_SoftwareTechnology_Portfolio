package assignment1.au615049;

public class Constants {
    public static final String COUNTRYNAME = "CountryName";
    public static final String COUNTRYCASES = "CountryCases";
    public static final String COUNTRYDEATHS = "CountryDeaths";
    public static final String COUNTRYNOTE = "CountryNote";
    public static final String COUNTRYRATING = "CountryRating";
    public static final String COUNTRYCLASS = "CountryClass";
    public static final String COUNTRYINDEX = "CountryIndex";
}
