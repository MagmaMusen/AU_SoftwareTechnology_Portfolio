package assignment1.au615049;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.util.ArrayList;

public class ListActivity extends AppCompatActivity implements CountryAdapter.ICountryItemClickedListener {

    public static final int REQUEST_CODE_COUNTRY_DETAIL = 101;
    public static final String INITIAL_DATA_CREATED = "InitialDataCreated";

    private Button btnExit;
    private RecyclerView rcvList;
    private CountryAdapter adapter;

    private CountryViewModel vm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        getSupportActionBar().setTitle("Coronavirus Tracker");

        // Find button.
        btnExit = findViewById(R.id.btnExit);

        // Live data setup.
        vm = new ViewModelProvider(this).get(CountryViewModel.class);

        // Adapter setup.
        adapter = new CountryAdapter(this, this);
        adapter.updateCountryList(vm.getCountryList());

        // Recycler view setup.
        rcvList = findViewById(R.id.rcvCountries);
        rcvList.setLayoutManager(new LinearLayoutManager(this));
        rcvList.setAdapter(adapter);




        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    @Override
    public void onCountryClicked(int index) {
        gotoDetailsActivity(index);
    }


    public void gotoDetailsActivity(int index){
        Country country = vm.getCountryList().get(index);

        Intent intent = new Intent(this, DetailsActivity.class);

        intent.putExtra(Constants.COUNTRYINDEX, index);
        intent.putExtra(Constants.COUNTRYCLASS, country);
        startActivityForResult(intent, REQUEST_CODE_COUNTRY_DETAIL);
    }

    // If something has been edited, set the data in the live data.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == REQUEST_CODE_COUNTRY_DETAIL)
        {
            if(resultCode == RESULT_OK)
            {
                //vm.getCountryList().set(data.getIntExtra(Constants.COUNTRYINDEX,0), (Country)data.getSerializableExtra(Constants.COUNTRYCLASS));
                vm.editCountry(data.getIntExtra(Constants.COUNTRYINDEX,0), (Country)data.getSerializableExtra(Constants.COUNTRYCLASS));
                adapter.updateCountryList(vm.getCountryList());
            }
        }
    }
}