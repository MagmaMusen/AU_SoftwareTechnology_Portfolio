package assignment1.au615049;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class DetailsActivity extends AppCompatActivity {

    public static final int REQUEST_CODE_COUNTRY_EDIT = 102;

    Button btnBack, btnEdit;
    TextView txtDeaths, txtCases, txtRating, txtName, txtNote;
    ImageView imgFlag;
    Country country;
    int index;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        getSupportActionBar().setTitle("Country Details");

        Intent data = getIntent();
        country = (Country)data.getSerializableExtra(Constants.COUNTRYCLASS);
        index = data.getIntExtra(Constants.COUNTRYINDEX,0);

        findActivityViews();
        setActivityViews();

        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gotoEditActivity();
            }
        });
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                back();
            }
        });
    }

    private void findActivityViews() {
        txtName = findViewById(R.id.txtCountryName);
        txtRating = findViewById(R.id.txtEditUserRating);
        txtCases = findViewById(R.id.txtCases);
        txtDeaths = findViewById(R.id.txtDeaths);
        txtNote = findViewById(R.id.txtUserNotes);
        btnBack = findViewById(R.id.btnBack);
        btnEdit = findViewById(R.id.btnEdit);
        imgFlag = findViewById(R.id.imgFlag);
    }

    private void setActivityViews(){
        txtCases.setText(String.valueOf(country.cases));
        txtDeaths.setText(String.valueOf(country.deaths));
        txtName.setText(country.name);
        txtNote.setText(country.getNote(this));
        txtRating.setText(country.getRating(this));
        imgFlag.setImageResource(country.getFlagResourceId());
    }

    private void gotoEditActivity() {
        Intent intent = new Intent(this, EditActivity.class);
        intent.putExtra(Constants.COUNTRYCLASS, country);
        startActivityForResult(intent, REQUEST_CODE_COUNTRY_EDIT);
    }

    private void back() {
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == REQUEST_CODE_COUNTRY_EDIT) {
            if(resultCode == RESULT_OK){
                setResult(RESULT_OK, data);
                data.putExtra(Constants.COUNTRYINDEX, index);
                finish();
            }
        }
    }
}